# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '3330c0171ad98a1bee3d1fa6c5186326c1752bbd6ecb84accdf991492c8e1b2e1f10c5e49b3a50348d391e75eded25ca293700a0784c0ef3330c463fd5b3e4fc'